package com.megvii.facepp.api.bean;

/**
 * @author by licheng on 2018/7/3.
 */

public class FaceSetDeleteResponse extends FaceSetCreatResponse {
}
