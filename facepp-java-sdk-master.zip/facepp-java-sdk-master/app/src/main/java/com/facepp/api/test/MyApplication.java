package com.facepp.api.test;

import android.app.Application;

/**
 * @author by licheng on 2018/6/29.
 */

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
